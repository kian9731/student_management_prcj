import 'package:dio/dio.dart';
import 'package:student_api/models/student.dart';


Future<List<Student>> getStudents() async{

  List<Student> studentsList= [];
    Dio dio=  Dio(BaseOptions(baseUrl: "http://expertdevelopers.ir/api/v1/"));
     final res= await dio.get("experts/student");

     if(res.data is  List){
      for(var item in res.data)
        {
         Student std= Student.fromJson(item);
         studentsList.add(std);
        }
     }
  print(studentsList);
  return studentsList;
}